# Tesla Website Design

As a small project to learn more about front-end development, I decided to recreate the Tesla Roadster website page. I used
bootstrap to create the project.

![hello](https://user-images.githubusercontent.com/49074690/74900997-7ead8e00-536f-11ea-9b49-e850b219f351.png)

![Screen Shot 2020-02-19 at 11 26 46 PM](https://user-images.githubusercontent.com/49074690/74901125-db10ad80-536f-11ea-92cf-91b95f1cc34f.png)

![Screen Shot 2020-02-19 at 11 26 58 PM](https://user-images.githubusercontent.com/49074690/74901120-d9df8080-536f-11ea-9068-93f1cd55a16e.png)

